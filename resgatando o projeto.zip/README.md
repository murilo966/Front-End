<p>
  <a href="https://opensource.org/licenses/MIT">
    <img src="https://img.shields.io/badge/License-MIT-blue.svg" alt="License MIT">   
    <img src="https://img.shields.io/github/followers/andrecomegno.svg" alt="Followers">
  </a>
</p>

<p align="left">
<img src="http://img.shields.io/static/v1?label=STATUS&message=EM%20DESENVOLVIMENTO&color=GREEN&style=for-the-badge"/>
</p>

<div>
  <p align="center">
    <img src="public/image/logo.jpg" alt="Logo" height="280">
  </p>
</div>

# Introdução
<p> O aplicativo está sendo desenvolvido no Senac, no curso de Full-Stack </p>

### 👾 Linguagens e Ferramentas
<img align="left" alt="React" width="30px" src="https://github.com/andrecomegno/andrecomegno/blob/main/icon/react.png" />
<img align="left" alt="JavaScript" width="30px" src="https://github.com/andrecomegno/andrecomegno/blob/main/icon/javascript.png" />
<img align="left" alt="CSS" width="30px" src="https://github.com/andrecomegno/andrecomegno/blob/main/icon/css3.png" />
<img align="left" alt="HTML" width="30px" src="https://github.com/andrecomegno/andrecomegno/blob/main/icon/html5.png" />
<img align="left" alt="VSCode" width="30px" src="https://github.com/andrecomegno/andrecomegno/blob/main/icon/vscode.png" />
<img align="left" alt="MySQL" width="30px" src="https://github.com/andrecomegno/andrecomegno/blob/main/icon/mysql.png" />
<br>

#

